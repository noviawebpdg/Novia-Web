# Novia Web — première version

Ouvre `index.html` dans un navigateur pour voir le site.

Le formulaire de contact est actuellement une démonstration : il ne transmet pas encore de vrais messages.
La prochaine étape sera de choisir un hébergement et de connecter un vrai formulaire.

Le site est volontairement sans dépendances externes pour rester simple à modifier et à mettre en ligne.
